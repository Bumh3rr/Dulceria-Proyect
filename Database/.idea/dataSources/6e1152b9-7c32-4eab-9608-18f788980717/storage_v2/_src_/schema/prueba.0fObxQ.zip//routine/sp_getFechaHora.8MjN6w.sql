create
    definer = root@localhost procedure sp_getFechaHora()
BEGIN
    SELECT NOW() AS "Fecha y Hora";
END;

