
package form;

import system.Form;

public class FormBuys extends Form{

}
