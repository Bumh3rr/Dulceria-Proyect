package utils;

public enum Request {
    INSERTS, UPDATE, DELETE
}
